from setuptools import setup, find_packages

setup(
    name="tp2Nahuel",
    version="0.1",
    packages=find_packages(),
    author="Nahuel Hermosa",
    description="un paquete de ejemplo en pyton",
    python_requires=">=3.6",
)